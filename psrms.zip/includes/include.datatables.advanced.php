<!--<link href="/assets/vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
<link href="/assets/vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">-->
<link href="/assets/vendor/NewFolder/DataTables-1.10.16/css/dataTables.bootstrap.css" rel="stylesheet">
<link href="/assets/vendor/NewFolder/Responsive-2.2.0/css/responsive.bootstrap.css" rel="stylesheet">

<!--<script src="/assets/vendor/datatables/js/jquery.dataTables.min.js" defer></script>
<script src="/assets/vendor/datatables-plugins/dataTables.bootstrap.min.js" defer></script>
<script src="/assets/vendor/datatables-responsive/dataTables.responsive.js" defer></script>-->
<script src="/assets/vendor/NewFolder/datatables.min.js" defer></script>
<script src="/assets/vendor/NewFolder/DataTables-1.10.16/js/dataTables.bootstrap.min.js" defer></script>
<script src="/assets/vendor/NewFolder/Responsive-2.2.0/js/responsive.bootstrap.js" defer></script>
<script src="/assets/vendor/NewFolder/Buttons-1.4.2/js/buttons.bootstrap.min.js" defer></script>
<script src="/assets/vendor/NewFolder/Buttons-1.4.2/js/buttons.flash.min.js" defer></script>
<script src="/assets/vendor/NewFolder/JSZip-2.5.0/jszip.min.js" defer></script>
<script src="/assets/vendor/NewFolder/pdfmake-0.1.32/pdfmake.min.js" defer></script>
<script src="/assets/vendor/NewFolder/pdfmake-0.1.32/vfs_fonts.js" defer></script>
<script src="/assets/vendor/NewFolder/Buttons-1.4.2/js/buttons.html5.min.js" defer></script>
<script src="/assets/vendor/NewFolder/Buttons-1.4.2/js/buttons.print.min.js" defer></script>