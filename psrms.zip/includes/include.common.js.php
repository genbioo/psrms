<script src="/assets/vendor/jquery/jquery.min.js"></script>
<script src="/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="/assets/vendor/metisMenu/metisMenu.min.js"></script>
<script src="/assets/dist/js/sb-admin-2.js"></script>
<script src="/assets/vendor/raphael/raphael.min.js"></script>
<script src="/assets/vendor/morrisjs/morris.min.js"></script>