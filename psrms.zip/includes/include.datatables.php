<link href="/assets/vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
<link href="/assets/vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

<script src="/assets/vendor/datatables/js/jquery.dataTables.min.js" defer></script>
<script src="/assets/vendor/datatables-plugins/dataTables.bootstrap.min.js" defer></script>
<script src="/assets/vendor/datatables-responsive/dataTables.responsive.js" defer></script>